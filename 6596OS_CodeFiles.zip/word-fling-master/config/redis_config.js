var config = {
  host: '127.0.0.1',
  port: 6379,
  options: {
    //auth_pass: 'password' // enable as needed
  },
  db: 1 // selected Redis database
};

module.exports = config;
